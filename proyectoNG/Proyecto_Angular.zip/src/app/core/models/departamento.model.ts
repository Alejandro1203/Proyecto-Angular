export interface Departamento {
    id: number,
    name: string
    location: string
}