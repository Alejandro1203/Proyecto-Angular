export interface Empleado {
    id: number,
    name: string
    puesto: string
    id_departamento: number
}